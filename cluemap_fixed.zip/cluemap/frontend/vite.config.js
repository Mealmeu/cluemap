var _a;
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
var backendTarget = (_a = process.env.VITE_DEV_BACKEND_TARGET) !== null && _a !== void 0 ? _a : "http://localhost:8000";
export default defineConfig({
    plugins: [react()],
    server: {
        port: 5173,
        host: "0.0.0.0",
        allowedHosts: true,
        proxy: {
            "/api": {
                target: backendTarget,
                changeOrigin: true,
                secure: false
            }
        }
    },
    preview: {
        port: 4173,
        host: "0.0.0.0",
        allowedHosts: true
    }
});
