import { apiClient } from "./api/client";
import type { StudentHistoryResponse, TeacherProblemInsights, TeacherProblemStats } from "../types/api";

export const getTeacherProblemStats = async (problemId: number) => {
  const { data } = await apiClient.get<TeacherProblemStats>(`/teacher/problems/${problemId}/stats`);
  return data;
};

export const getTeacherProblemInsights = async (problemId: number) => {
  const { data } = await apiClient.get<TeacherProblemInsights>(`/teacher/problems/${problemId}/insights`);
  return data;
};

export const getStudentHistory = async (studentId: number) => {
  const { data } = await apiClient.get<StudentHistoryResponse>(`/teacher/students/${studentId}/history`);
  return data;
};
