import { apiClient } from "./api/client";
import type { Problem, ProblemListItem, ProblemPayload } from "../types/api";

export const getProblems = async () => {
  const { data } = await apiClient.get<ProblemListItem[]>("/problems");
  return data;
};

export const getProblem = async (problemId: number) => {
  const { data } = await apiClient.get<Problem>(`/problems/${problemId}`);
  return data;
};

export const createProblem = async (payload: ProblemPayload) => {
  const { data } = await apiClient.post<Problem>("/problems", payload);
  return data;
};

export const updateProblem = async (problemId: number, payload: Partial<ProblemPayload>) => {
  const { data } = await apiClient.put<Problem>(`/problems/${problemId}`, payload);
  return data;
};

export const deleteProblem = async (problemId: number) => {
  const { data } = await apiClient.delete<{ message: string }>(`/problems/${problemId}`);
  return data;
};
